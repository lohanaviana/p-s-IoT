package br.edu.ufam.icomp.projetoeltrico;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void loginClicado (View view){
        Intent intent = new Intent(this, ComodoActivity.class);
        startActivity(intent);
        EditText editText = (EditText) findViewById(R.id.login);
        String login = editText.getText().toString();
        String msg = "Você logou como" + login + "!!!";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}

    public void cadastroClicado (View view){
        Intent intent = new Intent(this, CadastroActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }



}


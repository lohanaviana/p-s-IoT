
package br.edu.ufam.icomp.projetoeltrico;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

public class EventosMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_menu);
    }

    public boolean onOptionItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sobre:
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.setMessage("Projeto Elétrico App V1.0")
                        .setNeutralButton("OK", null).show();

                return true;
             default:
                 return super.onOptionsItemSelected(item);
        }

    }
}
